"""Capture NVIDIA eDP brightness registers through the bundled gpu_aux backend."""

import argparse
import ctypes
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / "vendor"))


def show(message):
    print(message, flush=True)


def command_output(command):
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=20)
        return {"exit_code": result.returncode, "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip()}
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"error": str(error)}


def collect(aux):
    results = []
    adapters = aux.adapters()
    for adapter in adapters:
        show("GPU: " + adapter.name)
        for port in aux.ports(adapter):
            record = {"gpu": adapter.name, "port_identity": port.identity,
                      "display_name": port.name, "registers": {}}
            results.append(record)
            show("  Reading " + port.identity)
            try:
                for address, length in ((0x000, 16), (0x700, 16), (0x720, 16), (0x730, 8)):
                    data = aux.read_dpcd(port, address, length)
                    if len(data) != length:
                        raise RuntimeError("Short DPCD read at 0x%05x" % address)
                    record["registers"]["0x%05x" % address] = data.hex(" ")
                    show("    0x%05x: %s" % (address, data.hex(" ")))
                cap = bytes.fromhex(record["registers"]["0x00700"])
                control = bytes.fromhex(record["registers"]["0x00720"])
                luminance = bytes.fromhex(record["registers"]["0x00730"])
                record["decoded"] = {
                    "edp_revision_raw": cap[0],
                    "absolute_luminance_capable": bool(cap[3] & 0x10),
                    "mode_raw": "0x%02x" % control[1],
                    "control_mode": control[1] & 3,
                    "absolute_luminance_enabled": bool(control[1] & 0x80),
                    "relative_value": (control[2] << 8) | control[3],
                    "pwm_bit_count": control[4] & 31,
                    "pwm_bit_count_min": control[5] & 31,
                    "pwm_bit_count_max": control[6] & 31,
                    "target_luminance_field_millinit": int.from_bytes(luminance[4:7], "little"),
                    "target_is_a_physical_measurement": False,
                }
            except Exception as error:
                record["error"] = str(error)
                show("    Read failed: " + str(error))
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--hdr-state", choices=("off", "on", "unknown"), default="unknown")
    parser.add_argument("--slider-percent", type=int, choices=range(101), default=100,
                        metavar="0..100")
    args = parser.parse_args()
    if sys.platform != "win32" or ctypes.sizeof(ctypes.c_void_p) != 8:
        show("Use 64-bit Python 3.9+ on Windows x64.")
        return 2
    if not ctypes.windll.shell32.IsUserAnAdmin():
        show("Run this command in an Administrator terminal; normal UAC approval is required.")
        return 2
    report = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "platform": platform.platform(),
        "python": sys.version,
        "declared_hdr_state": args.hdr_state,
        "declared_slider_percent": args.slider_percent,
        "backend": "cnbright/gpu_aux",
        "backend_commit": "eda49e230b48a7a8b995b664a8a0756b2bde99f1",
        "dpcd_operations": "native read only",
        "expected_panel": "EDO EF25QBA63.E; unplug external displays to identify the internal port",
        "windows_hardware_tested_by_preparer": False,
    }
    show("[1/3] Capturing GPU and monitor information.")
    smi = shutil.which("nvidia-smi.exe")
    if smi:
        report["nvidia_driver"] = command_output(
            [smi, "--query-gpu=name,driver_version,vbios_version", "--format=csv,noheader"])
    powershell = str(Path(os.environ["SystemRoot"]) / "System32" /
                     "WindowsPowerShell" / "v1.0" / "powershell.exe")
    report["windows_monitor_info"] = command_output([
        powershell, "-NoProfile", "-NonInteractive", "-Command",
        "$ErrorActionPreference='Stop'; @{'brightness'=@(Get-CimInstance -Namespace root/wmi "
        "-ClassName WmiMonitorBrightness | Select-Object Active,CurrentBrightness,InstanceName); "
        "'monitors'=@(Get-CimInstance -Namespace root/wmi -ClassName WmiMonitorID | "
        "Select-Object Active,InstanceName,ManufacturerName,ProductCodeID,UserFriendlyName)} | "
        "ConvertTo-Json -Depth 5",
    ])
    status = 1
    try:
        show("[2/3] Reading DPCD brightness registers.")
        from gpu_aux.nvapi import NvidiaAux
        with NvidiaAux() as aux:
            report["ports"] = collect(aux)
        if any("decoded" in port and port["decoded"]["edp_revision_raw"] >= 1
               for port in report["ports"]):
            status = 0
        else:
            report["error"] = "No successful eDP register snapshot; keep the error report for analysis."
    except Exception as error:
        report["error"] = str(error)
        show("Capture failed: " + str(error))
    show("[3/3] Saving report.")
    output = BASE / ("windows-panel-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f") + ".json")
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    show("Saved: " + str(output))
    return status


if __name__ == "__main__":
    raise SystemExit(main())
